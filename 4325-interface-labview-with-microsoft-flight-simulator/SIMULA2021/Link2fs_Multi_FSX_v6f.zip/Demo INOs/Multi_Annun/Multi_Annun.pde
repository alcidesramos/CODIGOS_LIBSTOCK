

int AnunPinNo[9] = {2, 3, 4, 5, 6, 7, 8, 9, 10};// the selected pins with LED's
char AnunIdent2[9] = {'B','C','D','E','F','G','H','O','S'};//Selected items in "Annunciators" in Multi
int AnunPinValNew[9] = {0,0,0,0,0,0,0,0,0};//Array for pin values (The new readings)
int AnunPinValOld[9] = {0,0,0,0,0,0,0,0,0};//Array for pin values (The old readings)
int count = 0; //for array reading
int counterTrigger = 0;// Used for triggering the flashing LED's
int counterTriggerOld = 0;
long counter = 1; // Counter for read loops TO TIME THE FLASHING
int CodeIn;// Gets the serial read
int piezo = 11;//Was 11
int Anunbutton = 12;// the cancell alarm button in the Annunciator panel
int AnunPinTot = 0;//Used for cancelling alarms if fault disappears before pushing button

void setup(){
  for (count=0;count<9;count++) {// we make all the Anun declarations at once
    // Be careful with the above line.(Dont involve a pin that will have a switch on it ,, it can fry your pin or card)
    pinMode(AnunPinNo[count], OUTPUT);
   digitalWrite(AnunPinNo[count], LOW); 
  }
  pinMode(piezo, OUTPUT); // done the piezo seperately for clearer coding
  digitalWrite(piezo, LOW); 
  pinMode(Anunbutton, INPUT); // Cancell button on Anunnciators 
  digitalWrite(Anunbutton, HIGH);
  Serial.begin(115200);
}

void loop() {
  {OTHER();}
  {ANNUNBUTTON();}
  if (Serial.available()) { 
    CodeIn = getChar();   
    if (CodeIn == '=') {EQUALS();} 
    if (CodeIn == '<') {LESSTHAN();}
    if (CodeIn == '?') {QUESTION();}
    if (CodeIn == '/') {SLASH();}
  }
}

char getChar()
{
  while(Serial.available() == 0);
  return((char)Serial.read());
}

void OTHER(){
   // Normal "run" stuff in here
}

void EQUALS(){      
       CodeIn = getChar();
  switch(CodeIn) {
    case 'A':
       //Do something
    break;
     
    case 'W':
       //Do something
    break;
     
    case 'a':
       //Do something
    break;
       //etc etc etc
     }
}

void LESSTHAN(){    // The first identifier was "<"
      //Do something (See void EQUALS)
}

void QUESTION(){    // The first identifier was "?"
       //Do something (See void EQUALS)
}

void SLASH(){    // The first identifier was "/" (Annunciators)
  CodeIn = getChar();
 AnunPinTot = 0; // for turning OFF piezo after quick fault
  for (count=0;count<9;count++) {
   if (CodeIn == AnunIdent2[count]){
      AnunPinValNew[count] = (getChar()- 48); 
     if (AnunPinValNew[count] == 1){ 
       if (AnunPinValOld[count] < 1) {digitalWrite(AnunPinNo[count], HIGH);
         digitalWrite(piezo, HIGH);
         AnunPinValOld[count] = AnunPinValNew[count];}}
     if (AnunPinValNew[count] == 0){
       if (AnunPinValOld[count] > 0) {digitalWrite(AnunPinNo[count], LOW);AnunPinValOld[count] = AnunPinValNew[count]; 
   }}}
 if (AnunPinValOld[count] < 2 ){// for turning OFF piezo after quick fault
 AnunPinTot = (AnunPinTot + AnunPinValNew[count]);}
 //Serial.print(PinValNew[count]);
}
if (AnunPinTot < 1) {digitalWrite(piezo, LOW);} // for turning OFF piezo after quick fault
} 

void ANNUNBUTTON(){
  counter = counter + 1;
  if (counter < 50000){counterTrigger = 0;}else {counterTrigger = 1;}
  if (counter > 100000) {counter = 1;}
  if (digitalRead(Anunbutton) == 0){
     digitalWrite(piezo, LOW);
    for (count=0;count<9;count++) { 
     if (AnunPinValOld[count] == 1){AnunPinValOld[count] = 3;}
   }
   }
  if (counterTrigger != counterTriggerOld) {
   for (count=0;count<9;count++) {
    if (AnunPinValOld[count] == 3) {
    if (counterTrigger == 1){digitalWrite(AnunPinNo[count], HIGH);}
    if (counterTrigger == 0){digitalWrite(AnunPinNo[count], LOW);}
   }
  }
  counterTriggerOld = counterTrigger;  
  }
}









