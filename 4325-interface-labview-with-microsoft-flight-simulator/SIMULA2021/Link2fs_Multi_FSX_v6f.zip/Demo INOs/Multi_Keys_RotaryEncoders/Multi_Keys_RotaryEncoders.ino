
/* 
    This code is in the public domain
    For use with "Link2fs_Multi"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    
    This sets the Arduino Mega card for 3 rotary encoders and "keys" input except pin 13.
    Attach a switch to any pin from pin 8 upwards (except 13) and program that pin in "Multi"
    Everything to do with "Keys"  starts with a "K" in this code.
    Everything to do with rotary encoders starts with a "R" in this code.
    The Quadrature2 library is available from my site Jimspage.co.nz. (Special thanks to Bill Holland)
    It's here ,, http://www.jimspage.co.nz/encoders2.htm (Near the bottom of the page)
    Rotary encoder 1 is on pins 2 and 3
    Rotary encoder 2 is on pins 4 and 5
    Rotary encoder 3 is on pins 6 and 7
    The "push" switch on each one is connected to a "Keys" input pin and just seen as a switch.
    
    To change this to suit a Uno,, do the following ,,,,
    Line 29 ,, change "70"  to "20"
    Line 117 ,, change "70"  to  "20"
    That will make all the pins from pin 8 upwards on a Uno, as "Keys" input pins. (Except pin 13)

*/
#include "math.h"
#include "Quadrature.h"
Quadrature quad1(2, 3);
Quadrature quad2(4, 5);
Quadrature quad3(6, 7);

int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;

int R;// a variable
int Rold;// the old reading
int Rdif;// the difference since last loop
int R2;// a second test variable
int R3;// a second test variable
int Rold2;// a second loop old reading
int Rdif2; // the second test difference
int Rold3;// a second loop old reading
int Rdif3; // the second test difference

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 8; KoutPin < 70; KoutPin++)// Get all the pins ready for "Keys"  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
 Serial.begin(115200);   
}

void loop() {
  {KEYS();} //Check the "keys" section
  {ENCODER();} //Check the Rotary Encoders
  if (Serial.available()) {// Check if serial data has arrived from PC
    CodeIn = getChar();
    if (CodeIn == '=') {EQUALS();} // The first identifier is "="
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  }

}

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}

void EQUALS(){      // The first identifier was "="
 CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
    
         //etc etc etc
     }
}

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
       
         //etc etc etc
     }
}

void QUESTION(){    // The first identifier was "?"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
       
         //etc etc etc
     }
}
void SLASH(){    // The first identifier was "/" (Annunciator)
  //Do something
}
void KEYS() 
{
  Kstringnewstate = "";
  for (int KpinNo = 8; KpinNo < 70; KpinNo++){
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 8));
    if (KpinStateSTR != KoldpinStateSTR)
    {
      if (KpinNo != 13){
      Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
      }
    }
    Kstringnewstate += KpinStateSTR;
  }
  Kstringoldstate = Kstringnewstate;
}
void ENCODER(){
R =(quad1.position()/2); //The /2 is to suit the encoder(See my website)
  if (R != Rold) { // checks to see if it different
    (Rdif = (R-Rold));// finds out the difference
   if (Rdif == 1) Serial.println ("A01");//Com1 Mhz down
   if (Rdif == -1) Serial.println ("A02"); //Com1 Mhz up
   Rold = R; // overwrites the old reading with the new one.
  } 
  R2 =(quad2.position());
  if (R2 != Rold2) {
    (Rdif2 = (R2-Rold2));
    if (Rdif2 == 1) Serial.println ("A03"); // Com1 Khz down
    if (Rdif2 == -1) Serial.println ("A04");//Com1 Khz up
    Rold2 = R2;
  }
  R3 =(quad3.position());
  if (R3 != Rold3) {
    (Rdif3 = (R3-Rold3));
    if (Rdif3 == 1) Serial.println ("A55"); // VOR bug down
    if (Rdif3 == -1) Serial.println ("A56"); //VOR bug up
    Rold3 = R3;
  }
  
}




