
/* 
    This code is in the public domain
    For use with "Link2fs_Multi_ beta5b"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    
    This sets the Arduino Mega card to indicate gear position with the simconnect codes with 
    the remainder for inputs except pin 13.
    LED for gear (nose) onto pin 2 (Thru a resistor)
    LED for gear (left) onto pin 3 (Thru a resistor)
    LED for gear (right) onto pin 4 (Thru a resistor)
    LED for nose gear in transition onto pin 5 (Thru a resistor)
    LED for left gear in transition onto pin 6 (Thru a resistor)
    LED for right gear in transition onto pin 7 (Thru a resistor)
    For the gear control, attach 2 buttons (or a double throw toggle switch) to pins 8 and 9
    A switch on pin 10 will lower the flaps 1 notch
    A switch on pin 11 will raise the flaps 1 notch
    A switch on pin 12 will increase the Com1 Mhz (avoid pin 13 as an input ,, long story)
    A switch on pin 14 will decrease the Com1 Mhz
    A switch on pin 15 will set the transponder to 6543
    You need to tick "?Y" in "Link2fs_Multi".  (It's down the bottom of systems2)
    
    Attach a switch to any pin, 16 upwards and program that pin in "Multi Keys" section.
    Everything to do with "Keys"  starts with a "K" in this code.
    
    To change this for a Uno,, do the following ,,,,
    Line 46 ,, change "70"  to "19"
    Line 151 ,, change "70"  to  "19"
    That will make all the pins work as above. (Except pin 13)

*/


int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;
String gearSimple; 

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 8; KoutPin < 70; KoutPin++)// Get all the pins ready for simconnect codes and "Keys"(all inputs)  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  pinMode(2, OUTPUT); // gear nose LED
  pinMode(3, OUTPUT); // gear left LED
  pinMode(4, OUTPUT); // gear right LED
  pinMode(5, OUTPUT); // gear nose in transition LED
  pinMode(6, OUTPUT); // gear left in transition LED
  pinMode(7, OUTPUT); // gear right in transition LED
  
 Serial.begin(115200);   
}

void loop() {
  {INPUTS();} //Check the Simconnect and "keys" section for any input pins
  {OTHER();}// Check for "Other" things to do. (Non extraction stuff)
  if (Serial.available()) {
    CodeIn = getChar();
    if (CodeIn == '=') {EQUALS();} // The first identifier is "="
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  }
} // end of void loop (The main one)

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}// end of getchar void. 

void OTHER(){
/* In here you would put code that uses other data that
cant be put into an "extraction void" that references something else.
Also in here you would put code to do something that was not
relying on a current extraction trigger.
Or ,, you could just put it all in the main "void loop" and not worry about this "other void" at all.
*/
}// end of "other" void

void EQUALS(){      // The first identifier was "="
 CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://The second identifier was an "A"
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
    
         //etc etc etc
     }
}// end of equals loop

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
   case 'A'://The second identifier was an "A"
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
       //etc etc etc
     }
}// end of lessthan void

void QUESTION(){    // The first identifier was "?"
CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://The second identifier was an "A"
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'Y': // found the second identifier (the "Gear simple")
       gearSimple = "";
      gearSimple += getChar();// get first charactor (Nose gear)
      if (gearSimple == "2"){digitalWrite(2, HIGH);}else{digitalWrite(2, LOW);}
      if (gearSimple == "1"){digitalWrite(5, HIGH);}else{digitalWrite(5, LOW);}
      gearSimple += getChar(); // get the second charactor (gear left)
      if (gearSimple.endsWith("2")){digitalWrite(3, HIGH);}else{digitalWrite(3, LOW);}
      if (gearSimple.endsWith("1")){digitalWrite(6, HIGH);}else{digitalWrite(6, LOW);}
    gearSimple += getChar(); // get the third charactor  (gear right)
      if (gearSimple.endsWith("2")){digitalWrite(4, HIGH);}else{digitalWrite(4, LOW);}
      if (gearSimple.endsWith("1")){digitalWrite(7, HIGH);}else{digitalWrite(7, LOW);}
    break;
         //etc etc etc
     }
}// end of question void

void SLASH(){    // The first identifier was "/" (Annunciator)
  //Do something (See the other voids for layout)
} // end of slash void

void INPUTS() // Simconnect codes and "Keys" section
{
  Kstringnewstate = "";
  for (int KpinNo = 8; KpinNo < 70; KpinNo++){ //set to the input pins. (pins 8 to 70 ,, change the 70 to 19 for Uno cards)
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 8));// set to the first pin read (The 8)
    if (KpinStateSTR != KoldpinStateSTR)// checks if it's different to the last reading of that pinNo
    {
      if (KpinNo != 13){ // avoid using pin 13 as an input unless you know the tricks.
        if (KpinNo == 8 && KpinStateSTR == "0"){Serial.println ("C01");} //sets gear handle up
        if (KpinNo == 9 && KpinStateSTR == "0"){Serial.println ("C02");} //sets gear handle down
        if (KpinNo == 10 && KpinStateSTR == "0"){Serial.println ("C15");} //Decrements flap handle position
        if (KpinNo == 11 && KpinStateSTR == "0"){Serial.println ("C14");} //Increments flap handle position
        if (KpinNo == 12 && KpinStateSTR == "0"){Serial.println ("A02");} //Increments COM1sb by one MHz
        if (KpinNo == 14 && KpinStateSTR == "0"){Serial.println ("A01");} //Decrements COM1sb by one MHz
        if (KpinNo == 15 && KpinStateSTR == "0"){Serial.println ("A426543");} //Sets transponder code to 6543
        //  Add more here but remember to change the figure in the next line down. (the 15)
        if (KpinNo > 15){ //Change pinNo number to same as the highest one used for simconnect codes.(the 15)
        Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
        }//end of 'its pinNo is greater than 12' 
      }//end of 'its not pin 13'
    }//end of 'its different'       
    Kstringnewstate += KpinStateSTR;
  }//end of 'for' loop (read the pins)
  Kstringoldstate = Kstringnewstate;
}//end of INPUTS void


