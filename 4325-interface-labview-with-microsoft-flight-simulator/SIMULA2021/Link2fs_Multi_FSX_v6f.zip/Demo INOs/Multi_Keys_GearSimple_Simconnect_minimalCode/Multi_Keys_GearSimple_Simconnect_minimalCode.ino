
/* 
    This code is in the public domain
    For use with "Link2fs_Multi_ beta5b"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    This INO is stripped of all the "other" stuff.
    See the INO "Multi_keys_Gearsimple_Simconnect" for any detail.
*/


int CodeIn;
int KpinNo; 
int Koutpin;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;
String gearSimple; 

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 8; KoutPin < 70; KoutPin++)  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  pinMode(2, OUTPUT); 
  pinMode(3, OUTPUT); 
  pinMode(4, OUTPUT); 
  pinMode(5, OUTPUT); 
  pinMode(6, OUTPUT); 
  pinMode(7, OUTPUT); 
 Serial.begin(115200);   
}// end of setup void

void loop() {
  {INPUTS();}// Check for any inputs 
  if (Serial.available()) {
    CodeIn = getChar();
    if (CodeIn == '?') {QUESTION();}
  }
} // end of void loop

char getChar()// gets the serial data
{
  while(Serial.available() == 0);
  return((char)Serial.read());
} // end of getChar


void QUESTION(){ 
CodeIn = getChar();
  switch(CodeIn) {
    case 'Y':// found the gearSimple
       gearSimple = "";
      gearSimple += getChar();
      if (gearSimple.endsWith("2")){digitalWrite(2, HIGH);}else{digitalWrite(2, LOW);} // gear nose is down
      if (gearSimple.endsWith("1")){digitalWrite(5, HIGH);}else{digitalWrite(5, LOW);} // gear nose is moving
      gearSimple += getChar(); 
      if (gearSimple.endsWith("2")){digitalWrite(3, HIGH);}else{digitalWrite(3, LOW);} // gear left
      if (gearSimple.endsWith("1")){digitalWrite(6, HIGH);}else{digitalWrite(6, LOW);}
    gearSimple += getChar(); 
      if (gearSimple.endsWith("2")){digitalWrite(4, HIGH);}else{digitalWrite(4, LOW);} //gear right
      if (gearSimple.endsWith("1")){digitalWrite(7, HIGH);}else{digitalWrite(7, LOW);}
    break;
     }
}// end of QUESTION void



void INPUTS() // Simconnect codes and "Keys" section
{
  Kstringnewstate = "";
  for (int KpinNo = 8; KpinNo < 70; KpinNo++){ 
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 8));
    if (KpinStateSTR != KoldpinStateSTR)
    {
      if (KpinNo != 13){ 
        if (KpinNo == 8 && KpinStateSTR == "0"){Serial.println ("C01");} //sets gear handle up
        if (KpinNo == 9 && KpinStateSTR == "0"){Serial.println ("C02");} //sets gear handle down
        if (KpinNo == 10 && KpinStateSTR == "0"){Serial.println ("C15");} //Decrements flap handle position
        if (KpinNo == 11 && KpinStateSTR == "0"){Serial.println ("C14");} //Increments flap handle position
        if (KpinNo == 12 && KpinStateSTR == "0"){Serial.println ("A02");} //Increments COM1sb by one MHz
        if (KpinNo == 14 && KpinStateSTR == "0"){Serial.println ("A01");} //Decrements COM1sb by one MHz
        if (KpinNo == 15 && KpinStateSTR == "0"){Serial.println ("A426543");} //Sets transponder code to 6543
        //  Add more here but remember to change the figure in the next line down. (the 15)
        if (KpinNo > 15){ //Change pinNo number to same as the highest one used for simconnect codes.(the 15)
        Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
        }
      }
    }      
    Kstringnewstate += KpinStateSTR;
  }
  Kstringoldstate = Kstringnewstate;
}// end of INPUTS void


