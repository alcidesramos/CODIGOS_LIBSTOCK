 
    /* 
    This code is in the public domain.
    For use with "Link2fs_Multi".
    Ensure "?d" (Local FSX time) is ticked in Link2fs_Multi.
    This INO is made with the Adruino IDE versiion 1.0.1
    It receives the time from FSX and sends back keycode triggers.
    It's of no use except for testing.
    It's only meant for TRUE Arduino cards.
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    */

int CodeIn;// used on earlier serial reads
String FSXtime;
String LastDigi;
 
void setup(){
    pinMode(13, OUTPUT);//Set up Pin 13 for a visual indication
   digitalWrite(13, LOW); //As above
    Serial.begin(115200); 
}

void loop() {
  CodeIn = GetChar();
    if (CodeIn == '?') {// The first identifier is "?" 
     CodeIn = GetChar();
     if (CodeIn == 'd'){// Second identifier is "d"
     FSXtime = "";
     FSXtime += GetChar();//Get the 6 digits
     FSXtime += GetChar();
     FSXtime += GetChar();
     FSXtime += GetChar();
     FSXtime += GetChar();
     FSXtime += GetChar();
     
     //now send some "key" codes
     Serial.print('D');
     Serial.print('0');
     Serial.print(FSXtime.charAt(5));
     Serial.println('0');
     
     // Pulse LED on and off
     if (digitalRead(13) == HIGH) {
     digitalWrite(13, LOW);}
   else{
     digitalWrite(13, HIGH);}
     }
  }
}//end of void loop

char GetChar() //Serial Read Function
{
  while(Serial.available() == 0);
  return(Serial.read());
}



