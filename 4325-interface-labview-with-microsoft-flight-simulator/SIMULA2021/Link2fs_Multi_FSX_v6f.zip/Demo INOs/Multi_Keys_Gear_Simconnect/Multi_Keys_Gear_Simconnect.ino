
/* 
    This code is in the public domain
    For use with "Link2fs_Multi_ beta5"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    
    This sets the Arduino Mega card to indicate gear position with the simconnect codes with 
    the remainder for inputs except pin 13.
    LED for gear (nose) onto pin 2 ((Thru a resistor)
    LED for gear (left) onto pin 3 ((Thru a resistor)
    LED for gear (right) onto pin 4 ((Thru a resistor)
    LED for gear (in transition) onto pin 5 (Thru a resistor)
    For the gear control, attach 2 buttons (or a double throw toggle switch) to pins 6 and 7
    A switch on pin 8 will lower the flaps 1 notch
    A switch on pin 9 will raise the flaps 1 notch
    A switch on pin 10 will increase the Com1 Mhz
    A switch on pin 11 will decrease the Com1 Mhz
    A switch on pin 12 will set the transponder to 6543
    
    Attach a switch to any pin, 14 upwards(except 13) and program that pin in "Multi Keys" section.
    Everything to do with "Keys"  starts with a "K" in this code.
    
    To change this for a Uno,, do the following ,,,,
    Line 29 ,, change "70"  to "20"
    Line 117 ,, change "70"  to  "20"
    That will make all the pins work as above. (Except pin 13)

*/


int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;
String gearN,gearL,gearR;
int gearNi,gearLi,gearRi;

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 6; KoutPin < 70; KoutPin++)// Get all the pins ready for simconnect codes and "Keys"(all inputs)  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  pinMode(2, OUTPUT); // gear nose LED
  pinMode(3, OUTPUT); // gear left LED
  pinMode(4, OUTPUT); // gear right LED
  pinMode(5, OUTPUT); // gear in transition LED
 Serial.begin(115200);   
}

void loop() {
  {INPUTS();} //Check the Simconnect and "keys" section
  {OTHER();}// Check for "Other" things to do. (Non extraction stuff)
  if (Serial.available()) {
    CodeIn = getChar();
    if (CodeIn == '=') {EQUALS();} // The first identifier is "="
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  }

}

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}
void OTHER(){
/* In here you would put code that uses other data that
cant be put into an "extraction void" that references something else.
Also in here you would put code to do something that was not
relying on a current extraction trigger.
*/

//Sort out the gear "in transition" LED
int gearTot = (gearNi + gearLi + gearRi);
if (gearTot == 300){digitalWrite(5, LOW);} 
else if (gearTot < 1){digitalWrite(5, LOW);}
else {digitalWrite(5, HIGH);}
}

void EQUALS(){      // The first identifier was "="
 CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
    
         //etc etc etc
     }
}

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier "GearN"
      gearN = "";
      gearN += getChar();
      gearN += getChar();
      gearN += getChar();
      gearNi = gearN.toInt(); // convert it to an integer (Thanks Phill)
      if (gearNi > 99){digitalWrite(2, HIGH);}else{digitalWrite(2, LOW);}
      // See "OTHER" for more uses of gearni
    break;
     
    case 'B':
      gearL = "";
      gearL += getChar();
      gearL += getChar();
      gearL += getChar();
      gearLi = gearL.toInt(); // convert it to an integer (Thanks Phill)
      if (gearLi > 99){digitalWrite(3, HIGH);}else{digitalWrite(3, LOW);}
      // See "OTHER" for more uses of gearLi
    break;
     
    case 'C':
        gearR = "";
      gearR += getChar();
      gearR += getChar();
      gearR += getChar();
      gearRi = gearR.toInt(); // convert it to an integer (Thanks Phill)
      if (gearRi > 99){digitalWrite(4, HIGH);}else{digitalWrite(4, LOW);}
      // See "OTHER" for more uses of gearRi
    break;
       
         //etc etc etc
     }
}

void QUESTION(){    // The first identifier was "?"
CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
       
         //etc etc etc
     }
}
void SLASH(){    // The first identifier was "/" (Annunciator)
  //Do something
}
void INPUTS() // Simconnect codes and "Keys" section
{
  Kstringnewstate = "";
  for (int KpinNo = 6; KpinNo < 70; KpinNo++){ //set to the input pins. (pins 6 to 70 ,, change for Uno cards)
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 6));// set to the first pin read (The 6)
    if (KpinStateSTR != KoldpinStateSTR)// checks if it's different to the last reading of that pinNo
    {
      if (KpinNo != 13){ // avoid using pin 13 as an input unless you know the tricks.
        if (KpinNo == 6 && KpinStateSTR == "0"){Serial.println ("C01");} //sets gear handle up
        if (KpinNo == 7 && KpinStateSTR == "0"){Serial.println ("C02");} //sets gear handle down
        if (KpinNo == 8 && KpinStateSTR == "0"){Serial.println ("C15");} //Decrements flap handle position
        if (KpinNo == 9 && KpinStateSTR == "0"){Serial.println ("C14");} //Increments flap handle position
        if (KpinNo == 10 && KpinStateSTR == "0"){Serial.println ("A02");} //Increments COM by one MHz
        if (KpinNo == 11 && KpinStateSTR == "0"){Serial.println ("A01");} //Decrements COM by one MHz
        if (KpinNo == 12 && KpinStateSTR == "0"){Serial.println ("A426543");} //Sets transponder code to 6543
        //  Add more here but remember to change the figure in the next line down. (the 12)
        if (KpinNo > 12){ //Change pinNo number to same as the highest one used for simconnect codes.(the 12)
        Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
        }//end of 'its pinNo is greater than 12' 
      }//end of 'its not pin 13'
    }//end of 'its different'       
    Kstringnewstate += KpinStateSTR;
  }//end of 'for' loop (read the pins)
  Kstringoldstate = Kstringnewstate;
}//end of INPUTS void


