
/* 
    This code is in the public domain
    For use with "Link2fs_Multi"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    
    Here is the basic concept of my lay-outs.
    You could actually use this INO as a starting point for your own project.
    Deleting all the comments makes it really simple to follow once you understand the concept
*/


int CodeIn;// The normal declearations go here

void setup(){
   Serial.begin(115200); 
       // The normal startup stuff goes here
}

void loop() {
  {OTHER();}// Check for "Other" things to do. (Non extraction stuff)
  if (Serial.available()) {  //Check if anything there
    CodeIn = getChar();      //Get a serial read if there is.
    if (CodeIn == '=') {EQUALS();} // The first identifier is "=" ,, goto void EQUALS
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<" ,, goto void LESSTHAN
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?" ,, goto void QUESTION
    if (CodeIn == '/') {SLASH();}// The first identifier is "/"  ,, goto void SLASH (Annunciators)
  }
}

char getChar()// Get a character from the serial buffer(Dont touch)
{
  while(Serial.available() == 0);// wait for data (Dont touch)
  return((char)Serial.read());// (Dont touch) Thanks Doug
}

void OTHER(){
/* In here you would put code that uses other data that
cant be put into an "extraction void" that references something else.
Also in here you would put code to do something that was not
relying on a current extraction.
(Remember - The identifier voids only trigger when it receives that identifier)
*/
}

void EQUALS(){      // The first identifier was "="
       CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'W':
       //Do something
    break;
     
    case 'a':
       //Do something
    break;
       //etc etc etc
       // You only need the "Case" testing for the identifiers you expect to use.
     }
}

void LESSTHAN(){    // The first identifier was "<"
      //Do something (See void EQUALS)
}

void QUESTION(){    // The first identifier was "?"
       //Do something (See void EQUALS)
}

void SLASH(){    // The first identifier was "/" (Annunciators)
  //Do something (See void EQUALS)
}










