
Link2fs Multi Beta 5..

Here are some basic INO's to start having a fiddle with the Multi program.
They have all been changed to suit the "linefeed" needed on all sent data from the Arduino.

The general lay-out will be a bit confusing to some people but it's actually rather simple to follow when you realize what is going on.

Data comes in,,,
The first identier shoots it to a seperate void.
In that void ,,  it is processed.
Then it returns to the Void loop.

A lot of the processing will be able to be done in the original "Identifier" void.

Now ,,  there are things that you require to happen that are not related to a particular extraction or there are things that need to be processed when no data is coming in ,, so in that case it shoots off to another void (ie "Other") to do that stuff which is being processed continuosly in the main "loop"
Also processing something that uses multipile variables would also be in that void.
An easy way to see this is to study all the attached INO's and especially the "Multi_Keys_Gear_Simconnect" one.
You only need the "Case" headings for the ones you plan to use ,,, I have added some blank ones to give you the idea which has made the whole INO look a bit "busy". Also all my comments have again, made it look "busy".

The above method greatly adds to the speed of reading and processing dual identifier data.

All the attached INO's are rather simple and it seem's crowded out with voids all over the place ,, well when there's a lot happening it will make a lot of sence and be easy to fault find or add-to another process to it.

There are other ways to do this (lot's of ways) ,,  but for me ,, I'm thinking ahead where there's going to be a lot happening and I dont want to read thru a book to find a single section ,, but you can do what ever you like.

For the above reasons ,, this really wasn't made for "Newbies" ,,,  if it dont make sence then have a play with the older "InOut" stuff (where there is a lot of stuff) and build up your skills ,, that in itself is a lot of fun. :)

Have fun ,,, Jim
P.S. Did I say to study the "Multi_Keys_Gear_Simconnect"  INO file.
It's an ideal "starter" file for you to expand with your needs.
