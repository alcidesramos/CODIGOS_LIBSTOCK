
/* 
    This code is in the public domain
    For use with "Link2fs_Multi_beta5d" or later"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    
    This is just a "demo" of switching the sim's lights on and off.
    Also there is a loop to indicate, via some LED's, if the individual lights are on or off.
    These all use simconnect.(not "keys")
    Some planes are not set up for individual switchings so just fiddle and 
    watch the extraction '<f' while clicking with your mouse ,,  most are OK tho.
    On some planes it is even upside-down on some switchs.
    It must have been a Monday morning job at M$ !!!
    The 10 '1's or '0's being sent equate to,,,, (in order, left to right) ,,,
    Nav, Beacon, Landing, Taxi, Strobe, Panel, Recognition, Wing, Logo, Cabin.
    
    These codes suit the use of TOGGLE switchs as are in the planes for this purpose.
    
    >>>>>>>> Make sure you have '<f' ticked in my program if you want the indications. <<<<<<<<<
    "Keys" starts from pin 32 upwards. (Mega)
*/


int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 22; KoutPin < 70; KoutPin++)// Get these pins ready as inputs  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  for (int KoutPin = 2; KoutPin < 21; KoutPin++)// Get these pins ready as outputs  
  {
    pinMode(KoutPin, OUTPUT);
    digitalWrite(KoutPin, LOW);  
  }
  
 Serial.begin(115200);   
}

void loop() {
  {KEYS();} //Check the "keys" section
  if (Serial.available()) {
    CodeIn = getChar();
    if (CodeIn == '=') {EQUALS();} // The first identifier is "="
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  }

}

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}

void EQUALS(){      // The first identifier was "="
 CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
    
         //etc etc etc
     }
}

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'f':
    for (int pinNo = 2; pinNo < 12; pinNo++){//The 10 LED's to indicate lights status
    int lights = getChar();
      if (lights =='1'){digitalWrite(pinNo, HIGH);}else{digitalWrite(pinNo, LOW);} 
    }
      break;   
     }
}

void QUESTION(){    // The first identifier was "?"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'C':
       //Do something
    break;
       
         //etc etc etc
     }
}
void SLASH(){    // The first identifier was "/" (Annunciator)
  //Do something
}
void KEYS() 
{
  Kstringnewstate = "";
  for (int KpinNo = 22; KpinNo < 70; KpinNo++){
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 22));
    if (KpinStateSTR != KoldpinStateSTR)
    {
      if (KpinNo == 22){if (KpinStateSTR == "1" ){Serial.println ("C410");}else {Serial.println ("C411");}}//Nav lights
      if (KpinNo == 23){if (KpinStateSTR == "1" ){Serial.println ("C420");}else {Serial.println ("C421");}}//Beacon lights
      if (KpinNo == 24){if (KpinStateSTR == "1" ){Serial.println ("C430");}else {Serial.println ("C431");}}//Landing lights
      if (KpinNo == 25){if (KpinStateSTR == "1" ){Serial.println ("C440");}else {Serial.println ("C441");}}//Taxi lights
      if (KpinNo == 26){if (KpinStateSTR == "1" ){Serial.println ("C450");}else {Serial.println ("C451");}}//Strobe lights
      if (KpinNo == 27){if (KpinStateSTR == "1" ){Serial.println ("C460");}else {Serial.println ("C461");}}//Panel lights
      if (KpinNo == 28){if (KpinStateSTR == "1" ){Serial.println ("C470");}else {Serial.println ("C471");}}//Recognitian lights
      if (KpinNo == 29){if (KpinStateSTR == "1" ){Serial.println ("C480");}else {Serial.println ("C481");}}//Wing lights
      if (KpinNo == 30){if (KpinStateSTR == "1" ){Serial.println ("C490");}else {Serial.println ("C491");}}//Logo lights
      if (KpinNo == 31){if (KpinStateSTR == "1" ){Serial.println ("C500");}else {Serial.println ("C501");}}//Cabin lights
      //now the "keys" bit. Note the pinNo 31 in the line above and the line below.
      if (KpinNo > 31){
      Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
      }
    }
    Kstringnewstate += KpinStateSTR;
  }
  Kstringoldstate = Kstringnewstate;
}









