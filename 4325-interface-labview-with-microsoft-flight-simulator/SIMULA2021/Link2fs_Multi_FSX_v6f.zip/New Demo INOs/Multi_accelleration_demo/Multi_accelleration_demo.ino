/*
  
 ======================================================
 
 This sketch for the "Multi" shows how to include accelleration to a rotary encoder.
 You need the library "quadrature2.zip" from ,,
 http://www.jimspage.co.nz/encoders2.htm 
 There are lot's of ways to do this ,, this is one of them.
 
 Simply it takes a check of the Arduino cards Millisecond count and uses that for a 'time since
 last cycle' to determin if the rotary encoder is being turned fast or not.
 =======================================================
 A rotary encoder is connected to pins 8 and 9
 It increases or decreases the heading bug.
 This example code is in the public domain.
 http://www.jimspage.co.nz/intro.htm 
 */
 
#include "math.h"
#include "Quadrature.h"
Quadrature quad1(8, 9);
int X;//the RE's present state (RE = rotary encoder)
int Xold;// the old reading
int Xdif;// the difference since last loop
int doutpin;
int CodeIn;
long timePrevious;
long timeNow;
long timeInterval = 80;//you adjust this for "your" feel of fast
int fastTurn = 0;//variable for turn-speed state

void setup() 
{ 
  Serial.begin(115200); 
  for (int doutPin = 2; doutPin <= 12; doutPin++)  
  {  
    pinMode(doutPin, INPUT);
    digitalWrite(doutPin, HIGH);  
  }  
}//end of setup

void loop() {
  timeNow = millis();//get the milli count. (for speed check)
   {ROTARYS();} // go and check the rotary encoder
  if (Serial.available()) { // now lets check the serial buffer for any input data
    CodeIn = getChar();
    //if (CodeIn == '=') {EQUALS();}// The first identifier is "="
    //if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    //if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  } // end of serial available
 }// end of void loop
 
char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}//end of getchar

void ROTARYS(){
  // Now the bit for the rotary encoder input
  X =(quad1.position()/2);
  if (X != Xold) { // checks to see if it different
   if(timeNow - timePrevious < timeInterval) {fastTurn = 1;}else{ fastTurn = 0;} //is it being turned fast or not ? 
    (Xdif = (X-Xold));// finds out the RE's difference (going backwards or forwards)
    
    if (Xdif == 1) {//knob is going forward
       if (fastTurn == 1){//yes it's being turned fast ,, else ,, it's being turned slow
      for (int accel = 1; accel <= 10; accel++){//loop to send "A57" 10 times ,, use more or less to suit.
        Serial.println ("A57");}// heading increase fast
       }else{//it's turned slow
       Serial.println ("A57");}// heading increase slow (sent once)
    }//end of forward
    
    if (Xdif == -1) {//knob is going backwards
      if (fastTurn == 1){  //yes it's being turned fast ,, else ,, it's being turned slow
      for (int accel = 1; accel <= 10; accel++){//loop to send "A58" 10 times
        Serial.println ("A58");}// heading decrease fast
       }else{//it's turned slow
       Serial.println ("A58");}// heading decrease slow (sent once)
    }//end of backwards
    
  if (quad1.position() > 1000){ // zero the rotary encoder count if too high or low
      quad1.position(0);
    }
    if (quad1.position() < -1000){
      quad1.position(0);
    }
    Xold = X; // overwrites the old reading with the new one.
    timePrevious = timeNow;//resets the previous time to timenow
  }//end of yes its different 
} // end of 'Rotarys'

