
/* 
    This code is in the public domain
    For use with "Link2fs_Multi"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    Attach LED's to pins 2,3 and 4 (thru resistors)
    Push button switchs onto pins 8 and 9 (flaps up a bit, flaps down a bit)
    This also checks the spare pins (10 upwards) for "keys" input except pin 13.
    
    >>>> You must tick "<G" (Flap position) in Multi. <<<<<<
*/


int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;
String flaps;

String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;

void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  
  for (int KoutPin = 8; KoutPin < 70; KoutPin++)// Set's up all the input pins  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  pinMode(2, OUTPUT); // Flaps are "not up" LED
  pinMode(3, OUTPUT); // Flaps are down 1st position LED
  pinMode(4, OUTPUT); // Flaps are down 2nd position LED
 Serial.begin(115200);   
}

void loop() {
  {KEYS();} //Check the "keys" section
  if (Serial.available()) {
    CodeIn = getChar();//get a character
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
  }//end of serial check
}//end of void loop

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'G'://Found the second identifier ("G" Flaps position)
      flaps = "";
      flaps += getChar();
      flaps += getChar();
      flaps += getChar();
      int flapsInt = flaps.toInt(); // convert it to an integer (Thanks Phill)
      if (flapsInt > 0) {digitalWrite(2, HIGH);} else {digitalWrite(2, LOW);}
      if (flapsInt > 5) {digitalWrite(3, HIGH);} else {digitalWrite(3, LOW);}
      if (flapsInt > 40) {digitalWrite(4, HIGH);} else {digitalWrite(4, LOW);}
    break;
     }
}

void KEYS() 
{
  Kstringnewstate = "";
  for (int KpinNo = 8; KpinNo < 70; KpinNo++){//check for inputs on pins 8 to 70
    KpinStateSTR = String(digitalRead(KpinNo)); //if you change the 8 in the line above ,, also change the 8 in the line below
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 8));
    if (KpinStateSTR != KoldpinStateSTR)//yes it's different
    {
      if (KpinNo != 13){ //pin 13 is no good as an input, it can "flutter" unless set up correctly
      if (KpinNo == 8 && KpinStateSTR == "0"){Serial.println ("C15");} //flap handle up a bit
      if (KpinNo == 9 && KpinStateSTR == "0"){Serial.println ("C14");} //flap handle down a bit
      if (KpinNo > 9){//now the keys bit
      Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
      }//end of keys bit
     }//end of its not pin 13
    }//end of yes its different
    Kstringnewstate += KpinStateSTR;
  }//end of 'For' loop
  Kstringoldstate = Kstringnewstate;
}// end of "inputs" void









