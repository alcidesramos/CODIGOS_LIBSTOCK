#include <LiquidCrystal.h>


/* 
    This code is in the public domain
    For use with "Link2fs_Multi"
    Jimspage.co.nz
    My thanks to the Guys that gave me snippets of code. 
    This is designed to be used with the Mega although it can be converted to use on the Uno.
    
    This is just a "demo" of switching the sim's lights on and off and showing the
    Autopilot target Altitude and the Vert.speed on a common 16x2 LCD.
    It also shows the Heading and Flaps settings.

    The LCD is connected to pins 2,3,4,5,6 and 7
    
    The light switchs all use simconnect.(not "keys") but the remaining
    pin's above pin 35 can be used for switchs using "Keys" in my program.
    Some planes are not set up for individual switchings so just fiddle and 
    watch the extraction '<f' while clicking with your mouse or testing with 
    the "Test" button ,,  most are OK tho.
    On some planes it is even upside-down on some switchs.
    It must have been a Monday morning job at M$ !!!
    The 10 '1's or '0's being sent equate to,,,, (in order, left to right) ,,,
    Nav, Beacon, Landing, Taxi, Strobe, Panel, Recognition, Wing, Logo, Cabin.
    
    These lights codes suit the use of TOGGLE switchs as are in the planes for this purpose.
    The other switchs are push button type. (Autopilot stuff, increase or decrease the
    target Altitude and Vert speed.)
    ==========================================
    YOU NEED TO TICK THE FOLLOWING IN THE "Multi"
    =b  AP Autopilot Alt set
    =c  AP Autopilot Vert sp set
    =d  AP heading set
    <G  Flaps position
    ==========================================
*/

#include <LiquidCrystal.h>
int CodeIn;// used on all serial reads
int KpinNo; 
int Koutpin;
LiquidCrystal lcd(7, 6, 5, 4, 3, 2);
String KoldpinStateSTR, KpinStateSTR, Kstringnewstate,Kstringoldstate;
String altit, altitold, vertsp, vertspold, hdgset, hdgsetold, flaps, flapsold;
void setup() 
{
  Kstringoldstate = "111111111111111111111111111111111111111111111111111111111111111111111";
  for (int KoutPin = 22; KoutPin < 70; KoutPin++)// Get these pins ready as inputs  
  {
    pinMode(KoutPin, INPUT);
    digitalWrite(KoutPin, HIGH);  
  }
  lcd.begin(16, 2);
  lcd.clear();
  lcd.print("Test");
 Serial.begin(115200);   
}

void loop() {
  {INPUTS();} //Check the "Inputs" section
  if (Serial.available()) {
    CodeIn = getChar();
    if (CodeIn == '=') {EQUALS();} // The first identifier is "="
    if (CodeIn == '<') {LESSTHAN();}// The first identifier is "<"
    if (CodeIn == '?') {QUESTION();}// The first identifier is "?"
    if (CodeIn == '/') {SLASH();}// The first identifier is "/" (Annunciators)
  }//end of serial read bit
}//end of void loop

char getChar()// Get a character from the serial buffer
{
  while(Serial.available() == 0);// wait for data
  return((char)Serial.read());// Thanks Doug
}

void EQUALS(){
  CodeIn = getChar(); // Get the second identifier
  switch(CodeIn) {// Now lets find what to do with it
   case 'b': // found AP altitude setting
      delay (11);
      altit = "";
      altit += getChar();
      altit += getChar();
      altit += getChar();
      altit += getChar();
      altit += getChar();
      if (altit != altitold){
        lcd.setCursor(7, 0);
        delay (11);//My LCD seems to need his
        lcd.print("Alt " + altit);
        altitold = altit;
      }        
    break;
   case 'c': // found vertical speed setting
      delay (11);
      vertsp = "";
      vertsp += getChar();
      vertsp += getChar();
      vertsp += getChar();
      vertsp += getChar();
      vertsp += getChar();
      if (vertsp != vertspold){
        lcd.setCursor(7, 1);
        delay (11);
        lcd.print("Vsp " + vertsp);
        vertspold = vertsp;
       }
      break;
   case 'd': // found AP heading setting
      delay (11);
      hdgset = "";
      hdgset += getChar();
      hdgset += getChar();
      hdgset += getChar();
      if (hdgset != hdgsetold){
        lcd.setCursor(0, 0);
        delay (11);
        lcd.print("Hd " + hdgset);
        hdgsetold = hdgset;
       }       
   break;
    }//end of case switch
  }// end of void equals

void LESSTHAN(){    // The first identifier was "<"
CodeIn = getChar(); // Get another character
  switch(CodeIn) {// Now lets find what to do with it
    case 'A'://Found the second identifier
       //Do something
    break;
     
    case 'B':
       //Do something
    break;
     
    case 'f':
       // Do something
      case 'G'://Found the second identifier ("G" Flaps position)
      flaps = "";
      flaps += getChar();
      flaps += getChar();
      flaps += getChar();
      if (flaps != flapsold){
      lcd.setCursor(0, 1);
        delay (11);
        lcd.print("Fp " + flaps); 
       flapsold = flaps; 
      }
      break; 
      }//end of case method  
   }//end of lessthan

void QUESTION(){    // The first identifier was "?"
//do something
}// end of question

void SLASH(){    // The first identifier was "/" (Annunciator)
  //Do something
}

void INPUTS() 
{
  Kstringnewstate = "";
  for (int KpinNo = 22; KpinNo < 70; KpinNo++){// Pins 22 thru to 69 are all inputs
    KpinStateSTR = String(digitalRead(KpinNo)); 
    KoldpinStateSTR = String(Kstringoldstate.charAt(KpinNo - 22));//the 22 needs to be the same as the 22 in the "for" loop line.
    if (KpinStateSTR != KoldpinStateSTR)
    {
      if (KpinNo == 22){if (KpinStateSTR == "1" ){Serial.println ("C410");}else {Serial.println ("C411");}}//Nav lights
      if (KpinNo == 23){if (KpinStateSTR == "1" ){Serial.println ("C420");}else {Serial.println ("C421");}}//Beacon lights
      if (KpinNo == 24){if (KpinStateSTR == "1" ){Serial.println ("C430");}else {Serial.println ("C431");}}//Landing lights
      if (KpinNo == 25){if (KpinStateSTR == "1" ){Serial.println ("C440");}else {Serial.println ("C441");}}//Taxi lights
      if (KpinNo == 26){if (KpinStateSTR == "1" ){Serial.println ("C450");}else {Serial.println ("C451");}}//Strobe lights
      if (KpinNo == 27){if (KpinStateSTR == "1" ){Serial.println ("C460");}else {Serial.println ("C461");}}//Panel lights
      if (KpinNo == 28){if (KpinStateSTR == "1" ){Serial.println ("C470");}else {Serial.println ("C471");}}//Recognitian lights
      if (KpinNo == 29){if (KpinStateSTR == "1" ){Serial.println ("C480");}else {Serial.println ("C481");}}//Wing lights
      if (KpinNo == 30){if (KpinStateSTR == "1" ){Serial.println ("C490");}else {Serial.println ("C491");}}//Logo lights
      if (KpinNo == 31){if (KpinStateSTR == "1" ){Serial.println ("C500");}else {Serial.println ("C501");}}//Cabin lights
      if (KpinNo == 32 & KpinStateSTR == "1" ){Serial.println ("B11");}//Autopilot altitude set
      if (KpinNo == 33 & KpinStateSTR == "1" ){Serial.println ("B12");}//Autopilot altitude set
      if (KpinNo == 34 & KpinStateSTR == "1" ){Serial.println ("B13");}//Autopilot vert speed set
      if (KpinNo == 35 & KpinStateSTR == "1" ){Serial.println ("B14");}//Autopilot vert speed set
      // add more direct inputs here but raise the pinNo (35) in the above live and the line below.
      //now the "keys" bit. Note the pinNo 35 in the line above and the line below.
      if (KpinNo > 35){
      Serial.print ("D"); 
      if (KpinNo < 10) Serial.print ("0");
      Serial.print (KpinNo);
      Serial.println (KpinStateSTR);
      }//end of "keys" bit
    }//end of yes it's different
    Kstringnewstate += KpinStateSTR;
  }//end of "for" loop
  Kstringoldstate = Kstringnewstate;
}//end of OUTPUTS void









