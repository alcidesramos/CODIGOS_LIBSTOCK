/*

This code is in the public doman.
JIMSPAGE.CO.NZ

This is just a basic demo for interfacing a pot to the "Simconnect Inputs" page. (Not in the 'Experts' section.)
Codes C56 thru to C65 require the span to be 0 to 100 percent for the inputs that require a pot.
It's not good code but it works. (Also look at the code in the link below)

For pot inputs for the 'Experts' section the range is generally 0 to 16383
There are some very good codes for that range here,,,,
http://www.mycockpit.org/forums/showthread.php?t=27995

Have fun.

*/
const int analogInPin = A0;  // Analog input pin that the potentiometer wiper is attached to
int sensorValue = 0;        // value read from the pot
int sensorValueOld = 55;
long previousMillis = 0;

void setup() {
  Serial.begin(115200); 
}

void loop() {
  //set up the analog read delay
  unsigned long currentMillis = millis();
  if(currentMillis - previousMillis > 33) {  // fiddle the 33 to suit time delay/speed
  previousMillis = currentMillis;
  // Lets read the analog in value:
  sensorValue = analogRead(analogInPin);
 // Now lets see if it's different 
  if (sensorValueOld > (sensorValue + 1)  ||  sensorValueOld < (sensorValue - 1)){ // gets rid of "flutter"
    Serial.print("C56"); // change the "C56" to suit your Link2fs slot
     int sensorValueX = map(sensorValue,0,1023,0,100); // use this line for throttles etc. (0 to 100)
      //int sensorValueX = map(sensorValue,0,1023,-100,100); // <<<  Use this line for trim. (-100 to 100)
    Serial.println(long(sensorValueX));
  sensorValueOld = sensorValue;
  }// end of "yes it's different" loop
 }// end of timed loop 
} // end of void loop
